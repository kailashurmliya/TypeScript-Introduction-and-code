# Typescript Introduction, Session by Navdeep Dhull
Resources
 - Presentation and Code Snippets
